import React from "react";

const Message = ({ onGetData }) => {
  return (
    <center className="mt-10 mb-10 ">
      <h1 className="font-bold text-3xl">
        Hello There is no Notes at this Moments
      </h1>
    </center>
  );
};

export default Message;
