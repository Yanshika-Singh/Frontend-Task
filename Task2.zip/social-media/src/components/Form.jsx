import React, { useContext, useRef } from "react";
import { PostList } from "../store/Post-list-store";
import { useNavigate } from "react-router-dom";

const Form = () => {
  const { addPost } = useContext(PostList);

  const navigate = useNavigate();

  const userIdElement = useRef();
  const postTitleElement = useRef();
  const postBodyElement = useRef();
  const reactionElement = useRef();
  const tagsElement = useRef();

  const handleSubmit = (event) => {
    event.preventDefault();

    const userId = userIdElement.current.value;
    const postTitle = postTitleElement.current.value;
    const postBody = postBodyElement.current.value;
    const reaction = reactionElement.current.value;
    const tags = tagsElement.current.value.split(" ");

    userIdElement.current.value = " ";
    postTitleElement.current.value = " ";
    postBodyElement.current.value = " ";
    reactionElement.current.value = " ";
    tagsElement.current.value = " ";

    fetch("https://dummyjson.com/posts/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: postTitle,
        body: postBody,
        reaction: reaction,
        userId: userId,
        tags: tags,
      }),
    })
      .then((res) => res.json())
      .then((post) => {
        addPost(post), navigate("/");
      });
  };

  return (
    <div>
      <form className="mx-5 my-3" onSubmit={handleSubmit}>
        <div className=" mb-3">
          <label htmlFor="userid" className="form-label">
            <b> User Name</b>
          </label>
          <input
            type="text"
            ref={userIdElement}
            className="form-control"
            id="userId"
          />
        </div>

        <div className=" mb-3">
          <label htmlFor="title" className="form-label">
            <b>Note Title</b>
          </label>
          <input
            type="text"
            ref={postTitleElement}
            className="form-control"
            id="title"
          />
        </div>
        <div className=" mb-3">
          <label htmlFor="body" className="form-label">
            <b>Notes Content</b>
          </label>
          <textarea
            ref={postBodyElement}
            rows="4"
            type="text"
            className="form-control"
            id="body"
          />
        </div>
        <div className=" mb-3">
          <label htmlFor="reaction" className="form-label">
            <b>Number of reaction</b>
          </label>
          <input
            type="text"
            ref={reactionElement}
            className="form-control"
            id="reaction"
          />
        </div>
        <div className=" mb-3">
          <label htmlFor="tags" className="form-label">
            <b>Enter Your Keys words</b>
          </label>
          <input
            type="text"
            ref={tagsElement}
            className="form-control"
            id="tags"
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Post
        </button>
      </form>
    </div>
  );
};

export default Form;
