import React, { useContext } from "react";
import { AiFillDelete } from "react-icons/ai";
import { PostList } from "../store/Post-list-store";

const Post = ({ post }) => {
  const { deletePost } = useContext(PostList);
  return (
    <div className="mx-10 my-10 d-flex  ">
      <div className="card d-flex " style={{ width: "18rem" }}>
        <div className="card-body">
          <h1 className="card-title font-bold text-center">
            {post.title}
            <span
              className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"
              onClick={() => deletePost(post.id)}
            >
              <AiFillDelete></AiFillDelete>
            </span>
          </h1>
          <p className="card-text mt-2 text-center">{post.body}</p>
          <div className="text-center">
            {post.tags &&
              post.tags.map((tag, index) => (
                <span key={index} className="badge text-bg-primary ml-2 mt-2">
                  {tag}
                </span>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Post;
