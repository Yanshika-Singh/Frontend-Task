import Post from "./Post";
import { PostList } from "../store/Post-list-store";
import { useContext, useEffect, useState } from "react";
import Message from "./Message";
import Loading from "./Loading";

const Postlist = () => {
  const { postList, fetching, addInitialPosts } = useContext(PostList);

  const handleGetData = () => {
    fetch("https://dummyjson.com/")
      .then((res) => {
        if (!res.ok) {
          throw new Error("Network response was not ok");
        }
        return res.json();
      })
      .then((data) => {
        addInitialPosts(data.posts);
      })
      .catch((error) => {
        console.error("There was a problem with the fetch operation:", error);
      });
  };

  return (
    <>
      {fetching && <Loading />}
      {!fetching && postList.length === 0 && (
        <Message onGetData={handleGetData} />
      )}
      {!fetching && postList.map((post) => <Post key={post.id} post={post} />)}
    </>
  );
};

export default Postlist;
