import React from "react";

const simple = () => {
  return (
    <div>
      
    </div>
  );
};

export default simple;
