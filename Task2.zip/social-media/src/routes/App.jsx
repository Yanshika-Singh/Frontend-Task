import "bootstrap/dist/css/bootstrap.min.css";
import Header from "../components/Header";
import { Outlet } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import "./App.css";
import PostListProvider from "../store/Post-list-store";
import { useState } from "react";
function App() {
  const [selectTab, setselectTab] = useState("Home");
  return (
    <PostListProvider>
      <div className="head">
        <Sidebar selectTab={selectTab} setselectTab={setselectTab}></Sidebar>
        <div className="med">
          <Header></Header>
          <Outlet />
        </div>
      </div>
    </PostListProvider>
  );
}

export default App;
