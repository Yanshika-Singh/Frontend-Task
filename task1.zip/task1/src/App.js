import './App.css';
import { useEffect, useState } from 'react';
function App() {
  let total_days = 7;
  const [data, setData] = useState([
    { heading: "Onboarding", inputs: new Array(total_days)},
    { heading: "Google Search Console Access", inputs: new Array(total_days)},
    { heading: "Google Analytics Access", inputs: new Array(total_days)},
    { heading: "Website Access", inputs: new Array(total_days)},
    { heading: "Technical Audit", inputs: new Array(total_days)},
    { heading: "Aanchor Text and Semantic Analysis", inputs: new Array(total_days)},
    { heading: "Competitor Analysis", inputs: new Array(total_days)},
    { heading: "Anchor Text/URL Mapping", inputs: new Array(total_days)},
    { heading: "Google Data Studio Report + Local Reporting Suite", inputs: new Array(total_days)},
    { heading: "Site Level optimization", inputs: new Array(total_days)},
    { heading: "On Page optimization", inputs: new Array(total_days)},
    { heading: "Content Creation", inputs: new Array(total_days)},
    { heading: "Content Publishing", inputs: new Array(total_days)},
    { heading: "Premium Press Release", inputs: new Array(total_days)},
    { heading: "Authority Niche Placements", inputs: new Array(total_days)},
    { heading: "Review Management", inputs: new Array(total_days)},
    { heading: "Index Links", inputs: new Array(total_days)},
    { heading: "Video Recap", inputs: new Array(total_days)}
    

  ])
  

  const handleFieldChange = (heading, index, value) => {
    let new_data = data;
    new_data.forEach((dt) => {
      if(dt.heading == heading){
        dt.inputs[index] = value;
      }
    })

    setData([...new_data])
  }

  useEffect(() => {
    console.log(data)
    // Call Update API from here!

  }, [data])
  return (
    <div className='main'>
        <table>
          <thead>
            <th colSpan={total_days + 1}>MONTH 1</th>
          </thead>
          <tbody>
            {data.map(dt => {
              return (  
                <tr key={dt.heading}>
                  <th>{dt.heading}</th>
                  {
                    Array.from({ length: total_days }, (_, index) => (
                      <td key={index}>
                        <input type='text' onBlur={(e) => handleFieldChange(dt.heading, index, e.target.value)} value={dt.index}></input>
                      </td>
                    ))
                  }
                </tr>
              )
            })}
          </tbody>
        </table>
    </div>
  );
}

export default App;
